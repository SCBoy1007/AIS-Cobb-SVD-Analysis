#!/usr/bin/env python3
"""
VWI Analysis Example

This script demonstrates how to use the VWI analysis modules for 
comprehensive spinal deformity assessment.
"""

import os
import sys
import numpy as np
from scipy.io import loadmat

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from analysis import VWICalculator, AutoFeatureDiscovery, GlobalMetricSearch, GroundTruthAnalyzer


def load_sample_data():
    """
    Load sample vertebrae data for demonstration.
    In practice, this would load from your actual dataset.
    """
    # Create sample vertebrae corner points (18 vertebrae × 4 corners × 2 coordinates)
    np.random.seed(42)  # For reproducible results
    
    sample_cases = []
    sample_cobb_angles = []
    
    for case_id in range(10):  # 10 sample cases
        # Generate sample vertebrae points
        vertebrae_points = []
        base_x = 256  # Center x coordinate
        
        for i in range(18):  # 18 vertebrae
            # Add some curvature simulation
            curve_factor = np.sin(i * 0.3) * (20 + case_id * 5)  # Simulate scoliosis curve
            
            y_center = 50 + i * 80  # Vertical spacing
            x_center = base_x + curve_factor
            
            # Generate 4 corner points for each vertebra
            width = 40 + np.random.normal(0, 5)
            height = 25 + np.random.normal(0, 3)
            
            # Top-left, Top-right, Bottom-left, Bottom-right
            tl = [x_center - width/2, y_center - height/2]
            tr = [x_center + width/2, y_center - height/2]
            bl = [x_center - width/2, y_center + height/2]
            br = [x_center + width/2, y_center + height/2]
            
            vertebrae_points.extend([tl, tr, bl, br])
        
        vertebrae_array = np.array(vertebrae_points, dtype=np.float32)
        sample_cases.append(vertebrae_array)
        
        # Generate corresponding Cobb angle
        max_curve = abs(curve_factor)
        cobb_angle = max_curve + np.random.normal(0, 3)
        sample_cobb_angles.append(cobb_angle)
    
    return sample_cases, sample_cobb_angles


def example_vwi_calculation():
    """Demonstrate basic VWI calculation."""
    print("=== VWI Calculation Example ===")
    
    sample_cases, _ = load_sample_data()
    calculator = VWICalculator()
    
    # Analyze first case
    vertebrae_data = sample_cases[0]
    
    # Calculate VWI for all vertebrae
    vwi_values = calculator.calculate_all_vwi(vertebrae_data)
    print(f"Individual VWI values: {list(vwi_values.keys())[:5]}...")  # Show first 5
    
    # Calculate regional VWI
    regional_vwi = calculator.calculate_regional_vwi(vwi_values)
    print(f"Regional VWI: {regional_vwi}")
    
    # Calculate advanced metrics
    advanced_metrics = calculator.calculate_advanced_metrics(vwi_values)
    print(f"Advanced metrics: {list(advanced_metrics.keys())}")
    
    # Generate report
    report = calculator.generate_vwi_report(vwi_values, advanced_metrics, regional_vwi)
    print("\nSample Report:")
    print(report[:500] + "...")  # Show first 500 characters
    
    print("\n" + "="*50 + "\n")


def example_feature_discovery():
    """Demonstrate automatic feature discovery."""
    print("=== Feature Discovery Example ===")
    
    sample_cases, sample_cobb_angles = load_sample_data()
    calculator = VWICalculator()
    
    # Prepare data for feature discovery
    case_data_list = []
    for vertebrae_data in sample_cases:
        # Calculate VWI and other metrics
        vwi_values = calculator.calculate_all_vwi(vertebrae_data)
        regional_vwi = calculator.calculate_regional_vwi(vwi_values)
        advanced_metrics = calculator.calculate_advanced_metrics(vwi_values)
        
        # Combine all features
        case_data = {}
        case_data.update(vwi_values)
        case_data.update({f"regional_{k}": v for k, v in regional_vwi.items()})
        case_data.update(advanced_metrics)
        
        case_data_list.append(case_data)
    
    # Run feature discovery
    discovery = AutoFeatureDiscovery("example_results/feature_discovery")
    results = discovery.run_comprehensive_analysis(case_data_list, sample_cobb_angles)
    
    # Display results
    opt_results = results.get('optimization_results', {})
    print(f"Best correlation: {opt_results.get('best_correlation', 0):.4f}")
    print(f"Best features: {opt_results.get('best_features', [])}")
    print(f"Best aggregation: {opt_results.get('best_aggregation', 'N/A')}")
    
    # Show top individual features
    top_features = results.get('top_individual_features', [])[:5]
    print("\nTop Individual Features:")
    for i, (feature, corr) in enumerate(top_features):
        print(f"  {i+1}. {feature}: {corr:.4f}")
    
    print("\n" + "="*50 + "\n")


def example_global_search():
    """Demonstrate global metric search."""
    print("=== Global Search Example ===")
    
    sample_cases, sample_cobb_angles = load_sample_data()
    
    # Run global search
    search = GlobalMetricSearch("example_results/global_search")
    results = search.run_comprehensive_analysis(sample_cases, sample_cobb_angles)
    
    # Display search results
    search_results = results.get('search_results', {})
    print(f"Best correlation: {search_results.get('best_correlation', 0):.4f}")
    print(f"Baseline correlation: {search_results.get('baseline_correlation', 0):.4f}")
    print(f"Improvement: {search_results.get('improvement', 0):.4f}")
    print(f"Combinations tested: {search_results.get('combinations_tested', 0)}")
    
    # Best combination details
    best_combo = search_results.get('best_combination', {})
    if best_combo:
        print(f"\nBest combination:")
        print(f"  Features: {best_combo.get('features', [])[:3]}...")  # Show first 3
        print(f"  Aggregation: {best_combo.get('aggregation', 'N/A')}")
    
    print("\n" + "="*50 + "\n")


def example_gt_analysis():
    """Demonstrate ground truth analysis and visualization."""
    print("=== Ground Truth Analysis Example ===")
    
    sample_cases, _ = load_sample_data()
    
    # Create a sample image (normally you'd load a real X-ray)
    import matplotlib.pyplot as plt
    
    # Create synthetic X-ray-like image
    img_height, img_width = 1600, 600
    sample_image = np.random.normal(100, 30, (img_height, img_width, 3)).astype(np.uint8)
    
    # Save sample image
    os.makedirs("example_results/gt_analysis", exist_ok=True)
    sample_img_path = "example_results/gt_analysis/sample_xray.png"
    plt.imsave(sample_img_path, sample_image, cmap='gray')
    
    # Analyze with GT analyzer
    analyzer = GroundTruthAnalyzer("example_results/gt_analysis")
    
    # Analyze single image
    vertebrae_data = sample_cases[0]
    output_path = "example_results/gt_analysis/sample_analysis.png"
    
    analysis_result = analyzer.visualize_spine_analysis(
        sample_img_path, vertebrae_data, output_path, show_curves=True
    )
    
    print(f"Analysis completed. Results: {list(analysis_result.keys())}")
    
    if 'curves' in analysis_result:
        curves = analysis_result['curves']
        print(f"Detected {len(curves)} spinal curves:")
        for i, curve in enumerate(curves):
            print(f"  Curve {i+1}: {curve['cobb_angle']:.1f}° ({curve['direction']})")
    
    if 'overall_severity' in analysis_result:
        print(f"Overall severity: {analysis_result['overall_severity']}")
    
    print(f"Visualization saved to: {output_path}")
    
    print("\n" + "="*50 + "\n")


def main():
    """Run all VWI analysis examples."""
    print("VTF-18V VWI Analysis Examples")
    print("="*50)
    
    # Create results directory
    os.makedirs("example_results", exist_ok=True)
    
    # Run examples
    example_vwi_calculation()
    example_feature_discovery()
    example_global_search()
    example_gt_analysis()
    
    print("All examples completed!")
    print("Check the 'example_results/' directory for output files.")


if __name__ == "__main__":
    main()