"""
Ground Truth Analysis Module

This module provides tools for analyzing ground truth annotations and 
generating visualizations for spinal deformity assessment.
Based on the original gt.py from the Search directory.
"""

import os
import cv2
import numpy as np
import math
import csv
from scipy.io import loadmat
from tqdm import tqdm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import pandas as pd

# Set global font to Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'


class GroundTruthAnalyzer:
    """
    Analyzer for ground truth spinal annotations.
    
    This class provides comprehensive tools for loading, processing, and
    visualizing ground truth spinal annotations with clinical metrics.
    """
    
    def __init__(self, output_dir: str = "gt_analysis"):
        """
        Initialize the ground truth analyzer.
        
        Args:
            output_dir: Directory to save analysis results
        """
        self.output_dir = output_dir
        
        # Vertebrae list from bottom to top
        self.vertebrae = ['L5', 'L4', 'L3', 'L2', 'L1', 'T12', 'T11', 'T10', 
                         'T9', 'T8', 'T7', 'T6', 'T5', 'T4', 'T3', 'T2', 'T1', 'C7']
        
        # Color scheme for different curves
        self.curve_colors = ['darkgreen', 'darkblue', 'darkred', 'darkorange']
        
        self.create_output_directory()
        
    def create_output_directory(self):
        """Create output directory if it doesn't exist."""
        os.makedirs(self.output_dir, exist_ok=True)
        
    def rearrange_pts(self, pts: np.ndarray) -> np.ndarray:
        """
        Rearrange vertebrae corner points to standard format.
        
        Args:
            pts: Array of corner points for vertebrae
            
        Returns:
            Rearranged points in standard format
        """
        boxes = []
        for k in range(0, len(pts), 4):
            pts_4 = pts[k:k + 4, :]
            x_inds = np.argsort(pts_4[:, 0])
            pt_l = np.asarray(pts_4[x_inds[:2], :])
            pt_r = np.asarray(pts_4[x_inds[2:], :])
            y_inds_l = np.argsort(pt_l[:, 1])
            y_inds_r = np.argsort(pt_r[:, 1])
            tl = pt_l[y_inds_l[0], :]
            bl = pt_l[y_inds_l[1], :]
            tr = pt_r[y_inds_r[0], :]
            br = pt_r[y_inds_r[1], :]
            boxes.extend([tl, tr, bl, br])
        return np.asarray(boxes, np.float32)
    
    def load_gt_annotation(self, labels_dir: str, img_name: str) -> Optional[np.ndarray]:
        """
        Load ground truth annotation from MAT file.
        
        Args:
            labels_dir: Directory containing label files
            img_name: Image filename
            
        Returns:
            Array of vertebrae points or None if loading fails
        """
        mat_name = os.path.splitext(img_name)[0] + '.mat'
        mat_path = os.path.join(labels_dir, mat_name)
        
        try:
            mat_data = loadmat(mat_path)
            
            # Try different possible key names
            possible_keys = ['p2', 'pts', 'points', 'landmarks']
            pts = None
            
            for key in possible_keys:
                if key in mat_data:
                    pts = mat_data[key]
                    break
                    
            if pts is None:
                # Try to find any numeric array
                for key, value in mat_data.items():
                    if isinstance(value, np.ndarray) and value.ndim == 2 and value.shape[1] == 2:
                        pts = value
                        break
                        
            if pts is not None:
                return self.rearrange_pts(pts)
            else:
                print(f"Warning: No valid points found in {mat_path}")
                return None
                
        except Exception as e:
            print(f"Error loading {mat_path}: {e}")
            return None
    
    def calculate_vertebra_center(self, vertebra_points: np.ndarray) -> Tuple[float, float]:
        """
        Calculate the center point of a vertebra.
        
        Args:
            vertebra_points: 4 corner points of the vertebra
            
        Returns:
            Tuple of (x, y) center coordinates
        """
        if len(vertebra_points) != 4:
            return (0, 0)
            
        center_x = np.mean(vertebra_points[:, 0])
        center_y = np.mean(vertebra_points[:, 1])
        return (center_x, center_y)
    
    def detect_curves(self, vertebrae_centers: List[Tuple[float, float]]) -> List[Dict[str, Any]]:
        """
        Detect spinal curves from vertebrae center points.
        
        Args:
            vertebrae_centers: List of (x, y) center coordinates
            
        Returns:
            List of detected curve dictionaries
        """
        if len(vertebrae_centers) < 3:
            return []
            
        curves = []
        
        # Calculate deviations from straight line
        y_coords = [center[1] for center in vertebrae_centers]
        x_coords = [center[0] for center in vertebrae_centers]
        
        # Fit line through all points
        if len(y_coords) > 1:
            z = np.polyfit(y_coords, x_coords, 1)
            p = np.poly1d(z)
            
            # Calculate deviations
            deviations = []
            for i, (x, y) in enumerate(vertebrae_centers):
                expected_x = p(y)
                deviation = x - expected_x
                deviations.append(deviation)
                
            # Find curve segments based on sign changes
            curve_start = 0
            current_sign = np.sign(deviations[0]) if deviations[0] != 0 else 1
            
            for i in range(1, len(deviations)):
                dev_sign = np.sign(deviations[i]) if deviations[i] != 0 else current_sign
                
                if dev_sign != current_sign or i == len(deviations) - 1:
                    # End of current curve
                    curve_end = i if i < len(deviations) - 1 else i
                    
                    if curve_end - curve_start >= 2:  # Minimum 3 vertebrae for a curve
                        # Calculate Cobb angle for this curve
                        curve_vertebrae = vertebrae_centers[curve_start:curve_end+1]
                        cobb_angle = self.calculate_cobb_angle(curve_vertebrae)
                        
                        if abs(cobb_angle) > 10:  # Only consider curves > 10 degrees
                            curves.append({
                                'start_idx': curve_start,
                                'end_idx': curve_end,
                                'vertebrae': [self.vertebrae[j] for j in range(curve_start, curve_end+1) 
                                            if j < len(self.vertebrae)],
                                'cobb_angle': cobb_angle,
                                'direction': 'left' if current_sign > 0 else 'right',
                                'apex_idx': curve_start + np.argmax(np.abs(deviations[curve_start:curve_end+1]))
                            })
                    
                    curve_start = i
                    current_sign = dev_sign
                    
        return curves
    
    def calculate_cobb_angle(self, vertebrae_centers: List[Tuple[float, float]]) -> float:
        """
        Calculate Cobb angle for a spinal curve.
        
        Args:
            vertebrae_centers: List of vertebrae center points in the curve
            
        Returns:
            Cobb angle in degrees
        """
        if len(vertebrae_centers) < 3:
            return 0.0
            
        # Get first and last vertebrae
        first_vertebra = vertebrae_centers[0]
        last_vertebra = vertebrae_centers[-1]
        
        # For more accurate Cobb angle, use the most tilted vertebrae at the ends
        if len(vertebrae_centers) >= 5:
            # Find the most tilted vertebrae near the ends
            start_candidates = vertebrae_centers[:3]
            end_candidates = vertebrae_centers[-3:]
            
            # Simple approach: use the endpoints
            first_vertebra = start_candidates[0]
            last_vertebra = end_candidates[-1]
        
        # Calculate angle between the lines
        # For simplicity, use the angle between the line connecting centers
        # and the vertical axis
        dx = last_vertebra[0] - first_vertebra[0]
        dy = last_vertebra[1] - first_vertebra[1]
        
        if dy == 0:
            return 0.0
            
        angle = math.degrees(math.atan2(abs(dx), abs(dy)))
        
        return angle
    
    def classify_curve_severity(self, cobb_angle: float) -> str:
        """
        Classify curve severity based on Cobb angle.
        
        Args:
            cobb_angle: Cobb angle in degrees
            
        Returns:
            Severity classification string
        """
        abs_angle = abs(cobb_angle)
        
        if abs_angle < 10:
            return "Normal"
        elif abs_angle < 25:
            return "Mild"
        elif abs_angle < 40:
            return "Moderate"
        elif abs_angle < 50:
            return "Severe"
        else:
            return "Very Severe"
    
    def visualize_spine_analysis(self, image_path: str, vertebrae_points: np.ndarray,
                               output_path: str, show_curves: bool = True) -> Dict[str, Any]:
        """
        Create visualization of spine analysis with detected curves.
        
        Args:
            image_path: Path to the input X-ray image
            vertebrae_points: Array of vertebrae corner points
            output_path: Path to save the visualization
            show_curves: Whether to show detected curves
            
        Returns:
            Dictionary containing analysis results
        """
        try:
            # Load image
            image = cv2.imread(image_path)
            if image is None:
                print(f"Error: Could not load image {image_path}")
                return {}
                
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # Create matplotlib figure
            fig, ax = plt.subplots(1, 1, figsize=(10, 15))
            ax.imshow(image_rgb)
            ax.set_title(f"Spine Analysis: {os.path.basename(image_path)}", fontsize=16, fontweight='bold')
            ax.axis('off')
            
            # Calculate vertebrae centers
            num_vertebrae = len(vertebrae_points) // 4
            vertebrae_centers = []
            
            for i in range(num_vertebrae):
                vertebra_pts = vertebrae_points[i*4:(i+1)*4]
                center = self.calculate_vertebra_center(vertebra_pts)
                vertebrae_centers.append(center)
                
                # Draw vertebra outline
                pts = vertebra_pts.reshape((-1, 1, 2)).astype(np.int32)
                # Reorder points for proper polygon drawing
                ordered_pts = np.array([vertebra_pts[0], vertebra_pts[1], vertebra_pts[3], vertebra_pts[2]])
                polygon = plt.Polygon(ordered_pts, fill=False, edgecolor='yellow', linewidth=2, alpha=0.7)
                ax.add_patch(polygon)
                
                # Label vertebra
                if i < len(self.vertebrae):
                    ax.text(center[0], center[1], self.vertebrae[i], 
                           ha='center', va='center', fontsize=10, fontweight='bold',
                           color='white', bbox=dict(boxstyle='round,pad=0.3', facecolor='black', alpha=0.7))
            
            analysis_results = {}
            
            if show_curves and len(vertebrae_centers) >= 3:
                # Detect and visualize curves
                curves = self.detect_curves(vertebrae_centers)
                analysis_results['curves'] = curves
                
                for i, curve in enumerate(curves):
                    color = self.curve_colors[i % len(self.curve_colors)]
                    
                    # Draw curve line
                    curve_centers = vertebrae_centers[curve['start_idx']:curve['end_idx']+1]
                    x_coords = [center[0] for center in curve_centers]
                    y_coords = [center[1] for center in curve_centers]
                    
                    ax.plot(x_coords, y_coords, color=color, linewidth=4, alpha=0.8, label=f"Curve {i+1}")
                    
                    # Mark apex
                    apex_center = curve_centers[curve['apex_idx'] - curve['start_idx']]
                    ax.plot(apex_center[0], apex_center[1], 'o', color=color, markersize=10, markeredgecolor='white', markeredgewidth=2)
                    
                    # Add curve information
                    severity = self.classify_curve_severity(curve['cobb_angle'])
                    curve_info = f"Curve {i+1}: {curve['cobb_angle']:.1f}° ({severity})"
                    ax.text(0.02, 0.98 - i*0.05, curve_info, transform=ax.transAxes,
                           fontsize=12, fontweight='bold', color=color,
                           bbox=dict(boxstyle='round,pad=0.5', facecolor='white', alpha=0.8))
                
                # Add overall analysis
                max_curve = max(curves, key=lambda x: abs(x['cobb_angle'])) if curves else None
                if max_curve:
                    overall_severity = self.classify_curve_severity(max_curve['cobb_angle'])
                    analysis_results['overall_severity'] = overall_severity
                    analysis_results['max_cobb_angle'] = max_curve['cobb_angle']
                    
                    ax.text(0.02, 0.02, f"Overall: {overall_severity} Scoliosis", transform=ax.transAxes,
                           fontsize=14, fontweight='bold', color='red',
                           bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.8))
            
            # Draw spine centerline
            if len(vertebrae_centers) >= 2:
                x_coords = [center[0] for center in vertebrae_centers]
                y_coords = [center[1] for center in vertebrae_centers]
                ax.plot(x_coords, y_coords, 'r--', linewidth=2, alpha=0.6, label='Spine Centerline')
            
            if show_curves and curves:
                ax.legend(loc='upper right', fontsize=10)
            
            plt.tight_layout()
            plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            
            analysis_results['visualization_saved'] = output_path
            analysis_results['vertebrae_count'] = num_vertebrae
            
            return analysis_results
            
        except Exception as e:
            print(f"Error creating visualization: {e}")
            return {}
    
    def batch_analyze_images(self, images_dir: str, labels_dir: str, 
                           image_list: List[str], output_dir: str) -> Dict[str, Any]:
        """
        Batch analyze multiple images.
        
        Args:
            images_dir: Directory containing input images
            labels_dir: Directory containing label files
            image_list: List of image filenames to process
            output_dir: Directory to save analysis results
            
        Returns:
            Dictionary containing batch analysis results
        """
        os.makedirs(output_dir, exist_ok=True)
        
        batch_results = {
            'processed_images': [],
            'failed_images': [],
            'analysis_summary': {}
        }
        
        all_curves = []
        severity_counts = {'Normal': 0, 'Mild': 0, 'Moderate': 0, 'Severe': 0, 'Very Severe': 0}
        
        for img_name in tqdm(image_list, desc="Analyzing images"):
            try:
                img_path = os.path.join(images_dir, img_name)
                
                # Load ground truth
                vertebrae_points = self.load_gt_annotation(labels_dir, img_name)
                if vertebrae_points is None:
                    batch_results['failed_images'].append(img_name)
                    continue
                
                # Create visualization
                output_filename = f"{os.path.splitext(img_name)[0]}_analysis.png"
                output_path = os.path.join(output_dir, output_filename)
                
                analysis_result = self.visualize_spine_analysis(img_path, vertebrae_points, output_path)
                
                if analysis_result:
                    analysis_result['image_name'] = img_name
                    batch_results['processed_images'].append(analysis_result)
                    
                    # Collect statistics
                    if 'curves' in analysis_result:
                        all_curves.extend(analysis_result['curves'])
                        
                    if 'overall_severity' in analysis_result:
                        severity = analysis_result['overall_severity']
                        if severity in severity_counts:
                            severity_counts[severity] += 1
                else:
                    batch_results['failed_images'].append(img_name)
                    
            except Exception as e:
                print(f"Error processing {img_name}: {e}")
                batch_results['failed_images'].append(img_name)
        
        # Generate summary statistics
        batch_results['analysis_summary'] = {
            'total_images': len(image_list),
            'successfully_processed': len(batch_results['processed_images']),
            'failed_to_process': len(batch_results['failed_images']),
            'total_curves_detected': len(all_curves),
            'severity_distribution': severity_counts
        }
        
        if all_curves:
            cobb_angles = [curve['cobb_angle'] for curve in all_curves]
            batch_results['analysis_summary']['cobb_angle_statistics'] = {
                'mean': float(np.mean(cobb_angles)),
                'std': float(np.std(cobb_angles)),
                'min': float(np.min(cobb_angles)),
                'max': float(np.max(cobb_angles)),
                'median': float(np.median(cobb_angles))
            }
        
        return batch_results
    
    def export_results_to_csv(self, batch_results: Dict[str, Any], 
                            csv_path: str):
        """
        Export analysis results to CSV file.
        
        Args:
            batch_results: Results from batch analysis
            csv_path: Path to save CSV file
        """
        rows = []
        
        for result in batch_results['processed_images']:
            base_row = {
                'image_name': result['image_name'],
                'vertebrae_count': result.get('vertebrae_count', 0),
                'overall_severity': result.get('overall_severity', 'Unknown'),
                'max_cobb_angle': result.get('max_cobb_angle', 0)
            }
            
            if 'curves' in result:
                for i, curve in enumerate(result['curves']):
                    row = base_row.copy()
                    row.update({
                        'curve_id': i + 1,
                        'curve_start_vertebra': curve['vertebrae'][0] if curve['vertebrae'] else '',
                        'curve_end_vertebra': curve['vertebrae'][-1] if curve['vertebrae'] else '',
                        'curve_cobb_angle': curve['cobb_angle'],
                        'curve_direction': curve['direction'],
                        'curve_severity': self.classify_curve_severity(curve['cobb_angle'])
                    })
                    rows.append(row)
            else:
                rows.append(base_row)
        
        df = pd.DataFrame(rows)
        df.to_csv(csv_path, index=False)
        print(f"Results exported to {csv_path}")