"""
Automatic Feature Discovery System for Scoliosis Analysis

This module implements an automated system for discovering optimal combinations
of spinal features that correlate with clinical metrics like Cobb angles.
"""

import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import pearsonr, spearmanr
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_selection import SelectKBest, f_regression, mutual_info_regression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, r2_score
import itertools
from typing import List, Dict, Tuple, Optional, Any
import datetime
import warnings
warnings.filterwarnings('ignore')


class AutoFeatureDiscovery:
    """
    Automatic feature discovery system for spinal deformity analysis.
    
    This class implements comprehensive feature engineering and selection
    methods to identify optimal combinations of spinal measurements that
    correlate with clinical outcomes.
    """
    
    def __init__(self, output_dir: str = "feature_discovery"):
        """
        Initialize the feature discovery system.
        
        Args:
            output_dir: Directory to save analysis results
        """
        self.output_dir = output_dir
        self.vertebrae = ['L5', 'L4', 'L3', 'L2', 'L1', 'T12', 'T11', 'T10', 
                         'T9', 'T8', 'T7', 'T6', 'T5', 'T4', 'T3', 'T2', 'T1', 'C7']
        
        # Define spinal regions
        self.regions = {
            'PT': ['T1', 'T2', 'T3', 'T4', 'T5'],  # Proximal Thoracic
            'MT': ['T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'],  # Main Thoracic
            'TL': ['T12', 'L1', 'L2', 'L3', 'L4', 'L5']  # Thoracolumbar/Lumbar
        }
        
        self.feature_operations = [
            'mean', 'std', 'min', 'max', 'range', 'sum', 'median',
            'skew', 'kurtosis', 'cv', 'percentile_25', 'percentile_75'
        ]
        
        self.aggregation_methods = ['sum', 'mean', 'max', 'min', 'std']
        
    def create_output_directory(self):
        """Create output directory if it doesn't exist."""
        import os
        os.makedirs(self.output_dir, exist_ok=True)
        
    def extract_basic_features(self, vertebrae_data: Dict[str, Any]) -> Dict[str, float]:
        """
        Extract basic geometric features from vertebrae data.
        
        Args:
            vertebrae_data: Dictionary containing vertebrae measurements
            
        Returns:
            Dictionary of extracted features
        """
        features = {}
        
        # Individual vertebra features
        for vertebra in self.vertebrae:
            if vertebra in vertebrae_data:
                vdata = vertebrae_data[vertebra]
                if isinstance(vdata, dict):
                    for key, value in vdata.items():
                        if isinstance(value, (int, float)) and not np.isnan(value):
                            features[f"{vertebra}_{key}"] = value
                elif isinstance(vdata, (int, float)) and not np.isnan(vdata):
                    features[vertebra] = vdata
                    
        return features
    
    def extract_statistical_features(self, values: List[float], prefix: str) -> Dict[str, float]:
        """
        Extract statistical features from a list of values.
        
        Args:
            values: List of numerical values
            prefix: Prefix for feature names
            
        Returns:
            Dictionary of statistical features
        """
        if not values or len(values) == 0:
            return {}
            
        valid_values = [v for v in values if not np.isnan(v)]
        if len(valid_values) == 0:
            return {}
            
        features = {}
        
        try:
            features[f"{prefix}_mean"] = np.mean(valid_values)
            features[f"{prefix}_std"] = np.std(valid_values)
            features[f"{prefix}_min"] = np.min(valid_values)
            features[f"{prefix}_max"] = np.max(valid_values)
            features[f"{prefix}_range"] = np.max(valid_values) - np.min(valid_values)
            features[f"{prefix}_sum"] = np.sum(valid_values)
            features[f"{prefix}_median"] = np.median(valid_values)
            
            if len(valid_values) > 1:
                features[f"{prefix}_skew"] = stats.skew(valid_values)
                features[f"{prefix}_kurtosis"] = stats.kurtosis(valid_values)
                
            if np.mean(valid_values) != 0:
                features[f"{prefix}_cv"] = np.std(valid_values) / np.mean(valid_values)
                
            features[f"{prefix}_percentile_25"] = np.percentile(valid_values, 25)
            features[f"{prefix}_percentile_75"] = np.percentile(valid_values, 75)
            
        except Exception as e:
            print(f"Error calculating statistical features for {prefix}: {e}")
            
        return features
    
    def extract_regional_features(self, vertebrae_data: Dict[str, Any]) -> Dict[str, float]:
        """
        Extract features aggregated by spinal regions.
        
        Args:
            vertebrae_data: Dictionary containing vertebrae measurements
            
        Returns:
            Dictionary of regional features
        """
        features = {}
        
        for region_name, vertebrae_list in self.regions.items():
            # Collect values for this region
            region_values = []
            for vertebra in vertebrae_list:
                if vertebra in vertebrae_data:
                    value = vertebrae_data[vertebra]
                    if isinstance(value, (int, float)) and not np.isnan(value):
                        region_values.append(value)
                        
            # Extract statistical features for this region
            region_features = self.extract_statistical_features(region_values, f"region_{region_name}")
            features.update(region_features)
            
        return features
    
    def extract_asymmetry_features(self, vertebrae_data: Dict[str, Any]) -> Dict[str, float]:
        """
        Extract asymmetry features between different spinal regions.
        
        Args:
            vertebrae_data: Dictionary containing vertebrae measurements
            
        Returns:
            Dictionary of asymmetry features
        """
        features = {}
        
        # Calculate regional means
        regional_means = {}
        for region_name, vertebrae_list in self.regions.items():
            values = []
            for vertebra in vertebrae_list:
                if vertebra in vertebrae_data:
                    value = vertebrae_data[vertebra]
                    if isinstance(value, (int, float)) and not np.isnan(value):
                        values.append(value)
            if values:
                regional_means[region_name] = np.mean(values)
                
        # Calculate ratios between regions
        region_pairs = [('PT', 'MT'), ('MT', 'TL'), ('PT', 'TL')]
        for r1, r2 in region_pairs:
            if r1 in regional_means and r2 in regional_means:
                if regional_means[r2] != 0:
                    features[f"{r1}_{r2}_ratio"] = regional_means[r1] / regional_means[r2]
                features[f"{r1}_{r2}_diff"] = abs(regional_means[r1] - regional_means[r2])
                
        return features
    
    def generate_composite_features(self, features: Dict[str, float]) -> Dict[str, float]:
        """
        Generate composite features using mathematical operations.
        
        Args:
            features: Dictionary of basic features
            
        Returns:
            Dictionary of composite features
        """
        composite_features = {}
        feature_names = list(features.keys())
        
        # Generate pairwise combinations
        for i, f1 in enumerate(feature_names[:20]):  # Limit to avoid explosion
            for j, f2 in enumerate(feature_names[i+1:21]):
                v1, v2 = features[f1], features[f2]
                
                if not (np.isnan(v1) or np.isnan(v2)):
                    # Addition and subtraction
                    composite_features[f"{f1}_plus_{f2}"] = v1 + v2
                    composite_features[f"{f1}_minus_{f2}"] = abs(v1 - v2)
                    
                    # Multiplication and division
                    composite_features[f"{f1}_times_{f2}"] = v1 * v2
                    if v2 != 0:
                        composite_features[f"{f1}_div_{f2}"] = v1 / v2
                        
        return composite_features
    
    def optimize_feature_combination(self, X: pd.DataFrame, y: np.ndarray,
                                   max_features: int = 5) -> Dict[str, Any]:
        """
        Optimize feature combinations for maximum correlation with target.
        
        Args:
            X: Feature matrix
            y: Target values (e.g., Cobb angles)
            max_features: Maximum number of features to combine
            
        Returns:
            Dictionary containing optimization results
        """
        best_correlation = 0
        best_features = []
        best_weights = []
        best_aggregation = 'mean'
        
        feature_names = X.columns.tolist()
        
        # Try different feature combinations
        for n_features in range(1, min(max_features + 1, len(feature_names) + 1)):
            for features in itertools.combinations(feature_names, n_features):
                if len(features) > 10:  # Skip very large combinations
                    continue
                    
                X_subset = X[list(features)]
                
                # Try different aggregation methods
                for agg_method in self.aggregation_methods:
                    try:
                        if agg_method == 'weighted_sum':
                            # Use Random Forest feature importance as weights
                            rf = RandomForestRegressor(n_estimators=50, random_state=42)
                            rf.fit(X_subset, y)
                            weights = rf.feature_importances_
                            combined_feature = np.sum(X_subset.values * weights, axis=1)
                        else:
                            # Standard aggregation
                            if agg_method == 'mean':
                                combined_feature = X_subset.mean(axis=1)
                            elif agg_method == 'sum':
                                combined_feature = X_subset.sum(axis=1)
                            elif agg_method == 'max':
                                combined_feature = X_subset.max(axis=1)
                            elif agg_method == 'min':
                                combined_feature = X_subset.min(axis=1)
                            elif agg_method == 'std':
                                combined_feature = X_subset.std(axis=1)
                            weights = [1.0] * len(features)
                            
                        # Calculate correlation
                        if len(np.unique(combined_feature)) > 1:
                            correlation = abs(pearsonr(combined_feature, y)[0])
                            
                            if correlation > best_correlation:
                                best_correlation = correlation
                                best_features = list(features)
                                best_weights = weights
                                best_aggregation = agg_method
                                
                    except Exception as e:
                        continue
                        
        return {
            'best_correlation': best_correlation,
            'best_features': best_features,
            'best_weights': best_weights,
            'best_aggregation': best_aggregation
        }
    
    def run_comprehensive_analysis(self, data: List[Dict[str, Any]], 
                                 targets: List[float]) -> Dict[str, Any]:
        """
        Run comprehensive feature discovery analysis.
        
        Args:
            data: List of data dictionaries for each case
            targets: List of target values (e.g., Cobb angles)
            
        Returns:
            Comprehensive analysis results
        """
        print("Starting comprehensive feature discovery analysis...")
        
        # Extract features for all cases
        all_features = []
        for case_data in data:
            case_features = {}
            
            # Basic features
            basic_features = self.extract_basic_features(case_data)
            case_features.update(basic_features)
            
            # Regional features
            regional_features = self.extract_regional_features(case_data)
            case_features.update(regional_features)
            
            # Asymmetry features
            asymmetry_features = self.extract_asymmetry_features(case_data)
            case_features.update(asymmetry_features)
            
            # Composite features (limited to avoid explosion)
            composite_features = self.generate_composite_features(basic_features)
            case_features.update(composite_features)
            
            all_features.append(case_features)
            
        # Convert to DataFrame
        df_features = pd.DataFrame(all_features)
        df_features = df_features.fillna(0)  # Fill NaN with 0
        
        # Remove features with zero variance
        df_features = df_features.loc[:, df_features.var() != 0]
        
        print(f"Extracted {len(df_features.columns)} features from {len(data)} cases")
        
        # Optimize feature combinations
        optimization_results = self.optimize_feature_combination(df_features, np.array(targets))
        
        # Additional analysis
        analysis_results = {
            'optimization_results': optimization_results,
            'feature_matrix_shape': df_features.shape,
            'total_features_extracted': len(df_features.columns),
            'analysis_timestamp': datetime.datetime.now().isoformat()
        }
        
        # Individual feature correlations
        individual_correlations = {}
        for col in df_features.columns:
            try:
                corr = pearsonr(df_features[col], targets)[0]
                if not np.isnan(corr):
                    individual_correlations[col] = abs(corr)
            except:
                continue
                
        # Top individual features
        sorted_correlations = sorted(individual_correlations.items(), 
                                   key=lambda x: x[1], reverse=True)
        analysis_results['top_individual_features'] = sorted_correlations[:20]
        
        return analysis_results
    
    def save_results(self, results: Dict[str, Any], filename: str = "feature_discovery_results.json"):
        """
        Save analysis results to file.
        
        Args:
            results: Analysis results dictionary
            filename: Output filename
        """
        import json
        import os
        
        self.create_output_directory()
        filepath = os.path.join(self.output_dir, filename)
        
        # Convert numpy types to Python types for JSON serialization
        def convert_types(obj):
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, dict):
                return {key: convert_types(value) for key, value in obj.items()}
            elif isinstance(obj, list):
                return [convert_types(item) for item in obj]
            return obj
            
        results_serializable = convert_types(results)
        
        with open(filepath, 'w') as f:
            json.dump(results_serializable, f, indent=2)
            
        print(f"Results saved to {filepath}")
        
    def generate_report(self, results: Dict[str, Any]) -> str:
        """
        Generate a comprehensive analysis report.
        
        Args:
            results: Analysis results dictionary
            
        Returns:
            Formatted report string
        """
        report = []
        report.append("=== Automatic Feature Discovery Report ===\n")
        
        # Optimization results
        opt_results = results.get('optimization_results', {})
        report.append("Best Feature Combination:")
        report.append(f"  Correlation: {opt_results.get('best_correlation', 0):.4f}")
        report.append(f"  Features: {opt_results.get('best_features', [])}")
        report.append(f"  Aggregation: {opt_results.get('best_aggregation', 'N/A')}")
        report.append("")
        
        # Top individual features
        top_features = results.get('top_individual_features', [])
        report.append("Top Individual Features:")
        for i, (feature, corr) in enumerate(top_features[:10]):
            report.append(f"  {i+1:2d}. {feature}: {corr:.4f}")
        report.append("")
        
        # Analysis summary
        report.append("Analysis Summary:")
        report.append(f"  Total features extracted: {results.get('total_features_extracted', 0)}")
        report.append(f"  Feature matrix shape: {results.get('feature_matrix_shape', 'N/A')}")
        report.append(f"  Analysis timestamp: {results.get('analysis_timestamp', 'N/A')}")
        
        return "\n".join(report)