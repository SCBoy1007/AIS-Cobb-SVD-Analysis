"""
VWI (Vertebral Wedge Index) Calculator

This module implements calculation of vertebral wedge indices and related 
spinal deformity metrics for scoliosis analysis.
"""

import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from typing import List, Dict, Tuple, Optional
import math


class VWICalculator:
    """
    Calculator for Vertebral Wedge Index and related spinal metrics.
    
    The VWI is calculated as the ratio of anterior to posterior vertebral heights,
    providing a measure of vertebral wedging in sagittal plane deformities.
    """
    
    # Vertebrae list from bottom to top
    VERTEBRAE = ['L5', 'L4', 'L3', 'L2', 'L1', 'T12', 'T11', 'T10', 'T9', 'T8', 
                 'T7', 'T6', 'T5', 'T4', 'T3', 'T2', 'T1', 'C7']
    
    # Lenke classification regions
    REGIONS = {
        'PT': ['T1', 'T2', 'T3', 'T4', 'T5'],  # Proximal Thoracic
        'MT': ['T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'],  # Main Thoracic
        'TL': ['T12', 'L1', 'L2', 'L3', 'L4', 'L5']  # Thoracolumbar/Lumbar
    }
    
    def __init__(self):
        """Initialize the VWI calculator."""
        pass
    
    def rearrange_pts(self, pts: np.ndarray) -> np.ndarray:
        """
        Rearrange vertebrae corner points to standard format.
        
        Args:
            pts: Array of corner points for vertebrae
            
        Returns:
            Rearranged points in standard format [top-left, top-right, bottom-left, bottom-right]
        """
        boxes = []
        for k in range(0, len(pts), 4):
            pts_4 = pts[k:k + 4, :]
            x_inds = np.argsort(pts_4[:, 0])
            pt_l = np.asarray(pts_4[x_inds[:2], :])
            pt_r = np.asarray(pts_4[x_inds[2:], :])
            y_inds_l = np.argsort(pt_l[:, 1])
            y_inds_r = np.argsort(pt_r[:, 1])
            tl = pt_l[y_inds_l[0], :]
            bl = pt_l[y_inds_l[1], :]
            tr = pt_r[y_inds_r[0], :]
            br = pt_r[y_inds_r[1], :]
            boxes.extend([tl, tr, bl, br])
        return np.asarray(boxes, np.float32)
    
    def calculate_vertebra_vwi(self, vertebra_points: np.ndarray) -> float:
        """
        Calculate VWI for a single vertebra.
        
        Args:
            vertebra_points: 4 corner points of the vertebra [TL, TR, BL, BR]
            
        Returns:
            VWI value (anterior height / posterior height)
        """
        if len(vertebra_points) != 4:
            return np.nan
            
        tl, tr, bl, br = vertebra_points
        
        # Calculate anterior (front) and posterior (back) heights
        anterior_height = np.linalg.norm(tl - bl)  # Left side height
        posterior_height = np.linalg.norm(tr - br)  # Right side height
        
        if posterior_height == 0:
            return np.nan
            
        vwi = anterior_height / posterior_height
        return vwi
    
    def calculate_all_vwi(self, vertebrae_points: np.ndarray) -> Dict[str, float]:
        """
        Calculate VWI for all vertebrae.
        
        Args:
            vertebrae_points: Array of all vertebrae corner points
            
        Returns:
            Dictionary mapping vertebra names to VWI values
        """
        points = self.rearrange_pts(vertebrae_points)
        vwi_values = {}
        
        num_vertebrae = len(points) // 4
        for i in range(num_vertebrae):
            if i < len(self.VERTEBRAE):
                vertebra_name = self.VERTEBRAE[i]
                vertebra_pts = points[i*4:(i+1)*4]
                vwi = self.calculate_vertebra_vwi(vertebra_pts)
                vwi_values[vertebra_name] = vwi
                
        return vwi_values
    
    def calculate_regional_vwi(self, vwi_values: Dict[str, float]) -> Dict[str, float]:
        """
        Calculate average VWI for each spinal region.
        
        Args:
            vwi_values: Dictionary of individual vertebra VWI values
            
        Returns:
            Dictionary of regional VWI averages
        """
        regional_vwi = {}
        
        for region_name, vertebrae in self.REGIONS.items():
            region_vwis = [vwi_values.get(v, np.nan) for v in vertebrae if v in vwi_values]
            region_vwis = [v for v in region_vwis if not np.isnan(v)]
            
            if region_vwis:
                regional_vwi[region_name] = np.mean(region_vwis)
            else:
                regional_vwi[region_name] = np.nan
                
        return regional_vwi
    
    def calculate_advanced_metrics(self, vwi_values: Dict[str, float]) -> Dict[str, float]:
        """
        Calculate advanced VWI-based metrics.
        
        Args:
            vwi_values: Dictionary of individual vertebra VWI values
            
        Returns:
            Dictionary of advanced metrics
        """
        valid_vwis = [v for v in vwi_values.values() if not np.isnan(v)]
        
        if not valid_vwis:
            return {}
            
        metrics = {
            'vwi_mean': np.mean(valid_vwis),
            'vwi_std': np.std(valid_vwis),
            'vwi_min': np.min(valid_vwis),
            'vwi_max': np.max(valid_vwis),
            'vwi_range': np.max(valid_vwis) - np.min(valid_vwis),
            'vwi_cv': np.std(valid_vwis) / np.mean(valid_vwis) if np.mean(valid_vwis) != 0 else np.nan
        }
        
        # Calculate asymmetry metrics
        regional_vwi = self.calculate_regional_vwi(vwi_values)
        if 'PT' in regional_vwi and 'MT' in regional_vwi:
            metrics['pt_mt_ratio'] = regional_vwi['PT'] / regional_vwi['MT'] if regional_vwi['MT'] != 0 else np.nan
        if 'MT' in regional_vwi and 'TL' in regional_vwi:
            metrics['mt_tl_ratio'] = regional_vwi['MT'] / regional_vwi['TL'] if regional_vwi['TL'] != 0 else np.nan
            
        return metrics
    
    def correlate_with_cobb(self, vwi_data: List[Dict], cobb_angles: List[float]) -> Dict[str, float]:
        """
        Calculate correlation between VWI metrics and Cobb angles.
        
        Args:
            vwi_data: List of VWI analysis results for each case
            cobb_angles: Corresponding Cobb angles
            
        Returns:
            Dictionary of correlation coefficients
        """
        if len(vwi_data) != len(cobb_angles):
            raise ValueError("VWI data and Cobb angles must have same length")
            
        correlations = {}
        
        # Extract metrics for correlation analysis
        metrics_to_test = ['vwi_mean', 'vwi_std', 'vwi_range', 'vwi_cv']
        
        for metric in metrics_to_test:
            metric_values = []
            valid_cobb = []
            
            for i, vwi_case in enumerate(vwi_data):
                if metric in vwi_case and not np.isnan(vwi_case[metric]):
                    metric_values.append(vwi_case[metric])
                    valid_cobb.append(cobb_angles[i])
                    
            if len(metric_values) > 1:
                corr, p_value = pearsonr(metric_values, valid_cobb)
                correlations[f'{metric}_correlation'] = corr
                correlations[f'{metric}_p_value'] = p_value
                
        return correlations
    
    def generate_vwi_report(self, vwi_values: Dict[str, float], 
                           advanced_metrics: Dict[str, float],
                           regional_vwi: Dict[str, float]) -> str:
        """
        Generate a comprehensive VWI analysis report.
        
        Args:
            vwi_values: Individual vertebra VWI values
            advanced_metrics: Advanced VWI metrics
            regional_vwi: Regional VWI averages
            
        Returns:
            Formatted report string
        """
        report = []
        report.append("=== VWI Analysis Report ===\n")
        
        # Individual vertebra VWI
        report.append("Individual Vertebra VWI:")
        for vertebra in self.VERTEBRAE:
            if vertebra in vwi_values:
                vwi = vwi_values[vertebra]
                if not np.isnan(vwi):
                    report.append(f"  {vertebra}: {vwi:.3f}")
                else:
                    report.append(f"  {vertebra}: N/A")
        report.append("")
        
        # Regional VWI
        report.append("Regional VWI Averages:")
        for region, vwi in regional_vwi.items():
            if not np.isnan(vwi):
                report.append(f"  {region}: {vwi:.3f}")
            else:
                report.append(f"  {region}: N/A")
        report.append("")
        
        # Advanced metrics
        report.append("Advanced Metrics:")
        for metric, value in advanced_metrics.items():
            if not np.isnan(value):
                report.append(f"  {metric}: {value:.3f}")
            else:
                report.append(f"  {metric}: N/A")
        
        return "\n".join(report)