"""
Global Metric Search for Spinal Deformity Analysis

This module implements a comprehensive search system for finding optimal
combinations of spinal measurements that correlate with clinical outcomes.
Based on the original globalSearch.py from the Search directory.
"""

import pandas as pd
import numpy as np
from scipy.stats import pearsonr, skew, kurtosis
from scipy.io import loadmat
import os
from typing import Dict, List, Tuple, Any, Optional
import json
import datetime
import warnings
warnings.filterwarnings('ignore')


class GlobalMetricSearch:
    """
    Global search system for optimal spinal metric combinations.
    
    This class implements comprehensive analysis including Lenke classification
    regions, advanced statistical measures, and correlation optimization.
    """
    
    def __init__(self, output_dir: str = "global_search_results"):
        """
        Initialize the global search system.
        
        Args:
            output_dir: Directory to save analysis results
        """
        self.output_dir = output_dir
        
        # Vertebrae list from bottom to top
        self.vertebrae = ['L5', 'L4', 'L3', 'L2', 'L1', 'T12', 'T11', 'T10', 
                         'T9', 'T8', 'T7', 'T6', 'T5', 'T4', 'T3', 'T2', 'T1', 'C7']
        
        # Lenke classification regions
        self.regions = {
            'PT': ['T1', 'T2', 'T3', 'T4', 'T5'],  # Proximal Thoracic
            'MT': ['T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'],  # Main Thoracic
            'TL': ['T12', 'L1', 'L2', 'L3', 'L4', 'L5']  # Thoracolumbar/Lumbar
        }
        
        # Analysis operations
        self.operations = [
            'mean', 'std', 'min', 'max', 'range', 'sum', 'median',
            'skew', 'kurtosis', 'cv', 'percentile_25', 'percentile_75'
        ]
        
        # Aggregation methods for combining features
        self.aggregation_methods = ['sum', 'mean', 'max', 'min', 'std', 'weighted_sum']
        
        self.create_output_directory()
        
    def create_output_directory(self):
        """Create output directory if it doesn't exist."""
        os.makedirs(self.output_dir, exist_ok=True)
        
    def rearrange_pts(self, pts: np.ndarray) -> np.ndarray:
        """
        Rearrange vertebrae corner points to standard format.
        
        Args:
            pts: Array of corner points for vertebrae
            
        Returns:
            Rearranged points in standard format
        """
        boxes = []
        for k in range(0, len(pts), 4):
            pts_4 = pts[k:k + 4, :]
            x_inds = np.argsort(pts_4[:, 0])
            pt_l = np.asarray(pts_4[x_inds[:2], :])
            pt_r = np.asarray(pts_4[x_inds[2:], :])
            y_inds_l = np.argsort(pt_l[:, 1])
            y_inds_r = np.argsort(pt_r[:, 1])
            tl = pt_l[y_inds_l[0], :]
            bl = pt_l[y_inds_l[1], :]
            tr = pt_r[y_inds_r[0], :]
            br = pt_r[y_inds_r[1], :]
            boxes.extend([tl, tr, bl, br])
        return np.asarray(boxes, np.float32)
    
    def calculate_vertebra_metrics(self, vertebra_points: np.ndarray) -> Dict[str, float]:
        """
        Calculate comprehensive metrics for a single vertebra.
        
        Args:
            vertebra_points: 4 corner points of the vertebra [TL, TR, BL, BR]
            
        Returns:
            Dictionary of calculated metrics
        """
        if len(vertebra_points) != 4:
            return {}
            
        tl, tr, bl, br = vertebra_points
        
        metrics = {}
        
        try:
            # Basic dimensions
            width_top = np.linalg.norm(tr - tl)
            width_bottom = np.linalg.norm(br - bl)
            height_left = np.linalg.norm(bl - tl)
            height_right = np.linalg.norm(br - tr)
            
            metrics['width_top'] = width_top
            metrics['width_bottom'] = width_bottom
            metrics['height_left'] = height_left
            metrics['height_right'] = height_right
            
            # Derived metrics
            metrics['width_avg'] = (width_top + width_bottom) / 2
            metrics['height_avg'] = (height_left + height_right) / 2
            metrics['width_diff'] = abs(width_top - width_bottom)
            metrics['height_diff'] = abs(height_left - height_right)
            
            # Area and aspect ratios
            metrics['area'] = width_top * height_left  # Approximate area
            if height_left > 0:
                metrics['aspect_ratio'] = width_top / height_left
            if width_bottom > 0:
                metrics['width_ratio'] = width_top / width_bottom
            if height_right > 0:
                metrics['height_ratio'] = height_left / height_right
                
            # Wedge index (VWI-like metric)
            if height_right > 0:
                metrics['wedge_index'] = height_left / height_right
                
            # Angular measurements
            # Angle of top edge
            if width_top > 0:
                top_angle = np.arctan2(tr[1] - tl[1], tr[0] - tl[0])
                metrics['top_angle'] = np.degrees(top_angle)
                
            # Angle of bottom edge  
            if width_bottom > 0:
                bottom_angle = np.arctan2(br[1] - bl[1], br[0] - bl[0])
                metrics['bottom_angle'] = np.degrees(bottom_angle)
                
            # Parallelogram deviation
            if 'top_angle' in metrics and 'bottom_angle' in metrics:
                metrics['angle_diff'] = abs(metrics['top_angle'] - metrics['bottom_angle'])
                
        except Exception as e:
            print(f"Error calculating vertebra metrics: {e}")
            
        return metrics
    
    def extract_vertebrae_features(self, vertebrae_data: np.ndarray) -> Dict[str, Dict[str, float]]:
        """
        Extract features for all vertebrae.
        
        Args:
            vertebrae_data: Array of all vertebrae corner points
            
        Returns:
            Dictionary mapping vertebra names to their metrics
        """
        points = self.rearrange_pts(vertebrae_data)
        vertebrae_features = {}
        
        num_vertebrae = len(points) // 4
        for i in range(num_vertebrae):
            if i < len(self.vertebrae):
                vertebra_name = self.vertebrae[i]
                vertebra_pts = points[i*4:(i+1)*4]
                metrics = self.calculate_vertebra_metrics(vertebra_pts)
                vertebrae_features[vertebra_name] = metrics
                
        return vertebrae_features
    
    def calculate_regional_statistics(self, vertebrae_features: Dict[str, Dict[str, float]], 
                                    metric_name: str) -> Dict[str, float]:
        """
        Calculate statistics for spinal regions.
        
        Args:
            vertebrae_features: Dictionary of vertebrae features
            metric_name: Name of the metric to analyze
            
        Returns:
            Dictionary of regional statistics
        """
        regional_stats = {}
        
        for region_name, vertebrae_list in self.regions.items():
            # Collect values for this region and metric
            values = []
            for vertebra in vertebrae_list:
                if (vertebra in vertebrae_features and 
                    metric_name in vertebrae_features[vertebra]):
                    value = vertebrae_features[vertebra][metric_name]
                    if not np.isnan(value):
                        values.append(value)
                        
            if len(values) > 0:
                # Calculate statistics
                stats = self.calculate_statistics(values, f"{region_name}_{metric_name}")
                regional_stats.update(stats)
                
        return regional_stats
    
    def calculate_statistics(self, values: List[float], prefix: str) -> Dict[str, float]:
        """
        Calculate comprehensive statistics for a list of values.
        
        Args:
            values: List of numerical values
            prefix: Prefix for statistic names
            
        Returns:
            Dictionary of calculated statistics
        """
        if not values or len(values) == 0:
            return {}
            
        stats_dict = {}
        
        try:
            # Basic statistics
            stats_dict[f"{prefix}_mean"] = np.mean(values)
            stats_dict[f"{prefix}_std"] = np.std(values)
            stats_dict[f"{prefix}_min"] = np.min(values)
            stats_dict[f"{prefix}_max"] = np.max(values)
            stats_dict[f"{prefix}_range"] = np.max(values) - np.min(values)
            stats_dict[f"{prefix}_sum"] = np.sum(values)
            stats_dict[f"{prefix}_median"] = np.median(values)
            
            # Advanced statistics
            if len(values) > 1:
                stats_dict[f"{prefix}_skew"] = skew(values)
                stats_dict[f"{prefix}_kurtosis"] = kurtosis(values)
                
            # Coefficient of variation
            if np.mean(values) != 0:
                stats_dict[f"{prefix}_cv"] = np.std(values) / np.mean(values)
                
            # Percentiles
            stats_dict[f"{prefix}_percentile_25"] = np.percentile(values, 25)
            stats_dict[f"{prefix}_percentile_75"] = np.percentile(values, 75)
            
        except Exception as e:
            print(f"Error calculating statistics for {prefix}: {e}")
            
        return stats_dict
    
    def search_optimal_combinations(self, all_features: List[Dict[str, float]], 
                                  target_values: List[float]) -> Dict[str, Any]:
        """
        Search for optimal feature combinations that correlate with target values.
        
        Args:
            all_features: List of feature dictionaries for each case
            target_values: List of target values (e.g., Cobb angles)
            
        Returns:
            Dictionary containing search results
        """
        print("Starting global search for optimal combinations...")
        
        # Convert to DataFrame
        df = pd.DataFrame(all_features)
        df = df.fillna(0)  # Fill NaN with 0
        
        # Remove columns with zero variance
        df = df.loc[:, df.var() != 0]
        
        best_correlation = 0
        best_combination = None
        baseline_correlation = 0
        
        feature_names = df.columns.tolist()
        
        # Calculate baseline correlation (traditional VWI if available)
        vwi_features = [col for col in feature_names if 'wedge_index' in col.lower()]
        if vwi_features:
            try:
                vwi_values = df[vwi_features].mean(axis=1)
                baseline_correlation = abs(pearsonr(vwi_values, target_values)[0])
            except:
                pass
                
        print(f"Baseline correlation: {baseline_correlation:.4f}")
        print(f"Searching through {len(feature_names)} features...")
        
        # Search through feature combinations
        max_combinations = 1000  # Limit to prevent excessive computation
        combination_count = 0
        
        # Try individual features first
        for feature in feature_names:
            if combination_count >= max_combinations:
                break
                
            try:
                correlation = abs(pearsonr(df[feature], target_values)[0])
                if correlation > best_correlation:
                    best_correlation = correlation
                    best_combination = {
                        'features': [feature],
                        'operations': ['identity'],
                        'weights': [1.0],
                        'aggregation': 'identity'
                    }
                combination_count += 1
            except:
                continue
                
        # Try pairs of features with different operations
        import itertools
        
        for feat1, feat2 in itertools.combinations(feature_names[:50], 2):  # Limit combinations
            if combination_count >= max_combinations:
                break
                
            for agg_method in ['sum', 'mean', 'max', 'std']:
                try:
                    if agg_method == 'sum':
                        combined = df[feat1] + df[feat2]
                    elif agg_method == 'mean':
                        combined = (df[feat1] + df[feat2]) / 2
                    elif agg_method == 'max':
                        combined = np.maximum(df[feat1], df[feat2])
                    elif agg_method == 'std':
                        combined = np.std([df[feat1], df[feat2]], axis=0)
                        
                    correlation = abs(pearsonr(combined, target_values)[0])
                    if correlation > best_correlation:
                        best_correlation = correlation
                        best_combination = {
                            'features': [feat1, feat2],
                            'operations': [agg_method],
                            'weights': [1.0, 1.0],
                            'aggregation': agg_method
                        }
                    combination_count += 1
                except:
                    continue
                    
        search_results = {
            'best_correlation': best_correlation,
            'baseline_correlation': baseline_correlation,
            'improvement': best_correlation - baseline_correlation,
            'best_combination': best_combination,
            'combinations_tested': combination_count,
            'total_features': len(feature_names)
        }
        
        print(f"Search completed. Best correlation: {best_correlation:.4f}")
        print(f"Improvement over baseline: {search_results['improvement']:.4f}")
        
        return search_results
    
    def run_comprehensive_analysis(self, data_list: List[np.ndarray], 
                                 cobb_angles: List[float]) -> Dict[str, Any]:
        """
        Run comprehensive global search analysis.
        
        Args:
            data_list: List of vertebrae point arrays for each case
            cobb_angles: List of corresponding Cobb angles
            
        Returns:
            Comprehensive analysis results
        """
        print("Starting comprehensive global search analysis...")
        
        all_case_features = []
        
        # Process each case
        for i, vertebrae_data in enumerate(data_list):
            print(f"Processing case {i+1}/{len(data_list)}")
            
            # Extract vertebrae features
            vertebrae_features = self.extract_vertebrae_features(vertebrae_data)
            
            # Collect all features for this case
            case_features = {}
            
            # Individual vertebra features
            for vertebra, metrics in vertebrae_features.items():
                for metric_name, value in metrics.items():
                    case_features[f"{vertebra}_{metric_name}"] = value
                    
            # Regional statistics for each metric type
            metric_types = set()
            for vertebra_metrics in vertebrae_features.values():
                metric_types.update(vertebra_metrics.keys())
                
            for metric_type in metric_types:
                regional_stats = self.calculate_regional_statistics(vertebrae_features, metric_type)
                case_features.update(regional_stats)
                
            # Global statistics
            for metric_type in metric_types:
                all_values = []
                for vertebra_metrics in vertebrae_features.values():
                    if metric_type in vertebra_metrics:
                        value = vertebra_metrics[metric_type]
                        if not np.isnan(value):
                            all_values.append(value)
                            
                if all_values:
                    global_stats = self.calculate_statistics(all_values, f"global_{metric_type}")
                    case_features.update(global_stats)
                    
            all_case_features.append(case_features)
            
        # Search for optimal combinations
        search_results = self.search_optimal_combinations(all_case_features, cobb_angles)
        
        # Compile final results
        analysis_results = {
            'search_results': search_results,
            'analysis_timestamp': datetime.datetime.now().isoformat(),
            'total_cases': len(data_list),
            'feature_extraction_summary': {
                'cases_processed': len(all_case_features),
                'avg_features_per_case': np.mean([len(cf) for cf in all_case_features]),
                'total_unique_features': len(set().union(*[cf.keys() for cf in all_case_features]))
            }
        }
        
        return analysis_results
    
    def save_results(self, results: Dict[str, Any], filename: str = "global_search_results.json"):
        """
        Save analysis results to file.
        
        Args:
            results: Analysis results dictionary
            filename: Output filename
        """
        filepath = os.path.join(self.output_dir, filename)
        
        # Convert numpy types for JSON serialization
        def convert_types(obj):
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, dict):
                return {key: convert_types(value) for key, value in obj.items()}
            elif isinstance(obj, list):
                return [convert_types(item) for item in obj]
            return obj
            
        results_serializable = convert_types(results)
        
        with open(filepath, 'w') as f:
            json.dump(results_serializable, f, indent=2)
            
        print(f"Results saved to {filepath}")
        
    def generate_report(self, results: Dict[str, Any]) -> str:
        """
        Generate a comprehensive analysis report.
        
        Args:
            results: Analysis results dictionary
            
        Returns:
            Formatted report string
        """
        report = []
        report.append("=== Global Metric Search Report ===\n")
        
        search_results = results.get('search_results', {})
        
        # Search summary
        report.append("Search Summary:")
        report.append(f"  Best correlation: {search_results.get('best_correlation', 0):.4f}")
        report.append(f"  Baseline correlation: {search_results.get('baseline_correlation', 0):.4f}")
        report.append(f"  Improvement: {search_results.get('improvement', 0):.4f}")
        report.append(f"  Combinations tested: {search_results.get('combinations_tested', 0)}")
        report.append("")
        
        # Best combination details
        best_combo = search_results.get('best_combination', {})
        if best_combo:
            report.append("Best Combination Details:")
            report.append(f"  Features: {best_combo.get('features', [])}")
            report.append(f"  Operations: {best_combo.get('operations', [])}")
            report.append(f"  Aggregation: {best_combo.get('aggregation', 'N/A')}")
            report.append("")
            
        # Analysis summary
        extraction_summary = results.get('feature_extraction_summary', {})
        report.append("Feature Extraction Summary:")
        report.append(f"  Cases processed: {extraction_summary.get('cases_processed', 0)}")
        report.append(f"  Avg features per case: {extraction_summary.get('avg_features_per_case', 0):.1f}")
        report.append(f"  Total unique features: {extraction_summary.get('total_unique_features', 0)}")
        report.append(f"  Analysis timestamp: {results.get('analysis_timestamp', 'N/A')}")
        
        return "\n".join(report)